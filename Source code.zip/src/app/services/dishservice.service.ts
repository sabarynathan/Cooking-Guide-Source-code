import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DishserviceService {
		currItemUrl:any;
		updateUrl:any;
		favUrl:any;
  constructor(private http: HttpClient) { }
  url="http://localhost:3000/";
  getData()
	{
		return this.http.get(this.url + "region/");
	}
	getSingleItem(id:any){
        this.currItemUrl = this.url + "dish/" + id;
        return this.http.get(this.currItemUrl);
    }
	update(data:any){
        this.updateUrl = this.url + "dish/" + data.id;
        return this.http.put(this.updateUrl,data);
    }
	addFavorites(data:any){
        this.favUrl = this.url + "favorites/";
        return this.http.post(this.favUrl,data);
    }
	getFavData()
	{
		return this.http.get(this.url + "favorites/");
	}
}
