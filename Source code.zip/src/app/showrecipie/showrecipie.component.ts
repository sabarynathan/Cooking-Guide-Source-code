import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { DishserviceService } from 'src/app/services/dishservice.service';
@Component({
  selector: 'app-showrecipie',
  templateUrl: './showrecipie.component.html',
  styleUrls: ['./showrecipie.component.css']
})
export class ShowrecipieComponent implements OnInit {
		singleItemDetails:any;
		dish:any;
  constructor(private route: ActivatedRoute,private getDishes: DishserviceService ) {
	  this.getSingleItemDetails(this.route.snapshot.params.id);
	 
  }

  ngOnInit(): void {
	  
  }
  getSingleItemDetails(id:any){
        this.getDishes.getSingleItem(id).subscribe((data:any)=>{
            this.singleItemDetails = data;
            this.updateDish();
			if(this.singleItemDetails.view === 5 ){
                this.addToFav();
            }
            console.log(this.singleItemDetails);
            debugger;
        });
    }
    
    updateDish(){
        this.singleItemDetails.view += 1; 
        this.getDishes.update(this.singleItemDetails).subscribe((data:any)=>{
            this.singleItemDetails = data;
        });
    }
    
    addToFav(){
        this.getDishes.addFavorites(this.singleItemDetails).subscribe((data:any)=>{
            this.singleItemDetails = data;
            console.log(data);
        });
    }
	
}
                     