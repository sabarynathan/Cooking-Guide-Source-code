import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowrecipieComponent } from './showrecipie.component';

describe('ShowrecipieComponent', () => {
  let component: ShowrecipieComponent;
  let fixture: ComponentFixture<ShowrecipieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowrecipieComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowrecipieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
