import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PopupreusecompComponent } from './popupreusecomp.component';

describe('PopupreusecompComponent', () => {
  let component: PopupreusecompComponent;
  let fixture: ComponentFixture<PopupreusecompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PopupreusecompComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PopupreusecompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
