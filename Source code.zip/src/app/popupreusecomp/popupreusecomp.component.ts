import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popupreusecomp',
  templateUrl: './popupreusecomp.component.html',
  styleUrls: ['./popupreusecomp.component.css']
})
export class PopupreusecompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
