import { Component, OnInit } from '@angular/core';
import { DishserviceService } from 'src/app/services/dishservice.service';
@Component({
  selector: 'app-favrecipies',
  templateUrl: './favrecipies.component.html',
  styleUrls: ['./favrecipies.component.css']
})
export class FavrecipiesComponent implements OnInit {

  dispDish:any;
  constructor(private getDishes: DishserviceService) {
		this.onGet();
	  }

  ngOnInit(): void {
  }
	onGet(){
      
        this.getDishes.getFavData().subscribe((data:any)=>{
            this.dispDish =  data ;
			console.log(this.dispDish);
        });
	}
}
