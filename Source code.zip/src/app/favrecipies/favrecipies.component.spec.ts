import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FavrecipiesComponent } from './favrecipies.component';

describe('FavrecipiesComponent', () => {
  let component: FavrecipiesComponent;
  let fixture: ComponentFixture<FavrecipiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FavrecipiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FavrecipiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
