import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowrecipieComponent } from './showrecipie/showrecipie.component';
import { FavrecipiesComponent } from './favrecipies/favrecipies.component';
import { PopupreusecompComponent } from './popupreusecomp/popupreusecomp.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    ShowrecipieComponent,
    FavrecipiesComponent,
    PopupreusecompComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
	HttpClientModule,
 NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
