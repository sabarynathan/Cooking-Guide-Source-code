import { Component } from '@angular/core';
import { DishserviceService } from './services/dishservice.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'cooking';
  dispDish:any;
  constructor(private getDishes: DishserviceService) {
		this.onGet();
	  }
  onGet(){
      
        this.getDishes.getData().subscribe((data:any)=>{
            this.dispDish =  data ;
			console.log(this.dispDish);
        });
	}
}

