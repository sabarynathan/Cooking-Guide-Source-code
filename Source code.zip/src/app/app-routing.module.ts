import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ShowrecipieComponent } from './showrecipie/showrecipie.component';
import { FavrecipiesComponent } from './favrecipies/favrecipies.component';
const routes: Routes = [
{path:"viewrecipie/:id",component:ShowrecipieComponent},
{path:"favoriterecipies",component:FavrecipiesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
